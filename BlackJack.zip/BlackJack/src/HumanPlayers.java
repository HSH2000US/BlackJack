public interface HumanPlayers
{
    public int setYourValues();
    public int addingValues();

}
